I could not find a direct evidence of the company providing us the Business Impact on a scale of 0-9. 
So I chose 9 as the project did say that the security of the web application is of the 'highest importance' to the company.
This was done both for the code-scan report, as well as the vulnerability report.
As a result, most of the severities stood up to be Critical or High.